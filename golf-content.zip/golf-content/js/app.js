// do not remove this line
$(document).foundation()

// write your own JS here:

